//
//  ViewController.swift
//  MoodTracker
//
//  Created by Code Academy on 1/2/25.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        resetButton.isHidden = true
    }
    
    // Variable Declaration
    var happyCount = 0
    var sarcasticCount = 0
    var loveCount = 0
    var angryCount = 0
    var partyCount = 0
    var sleepyCount = 0
    var upsetCount = 0
    var scaredCount = 0
    var cryCount = 0
    
    // IBOutlets - Gives names to objects on your view
    
    @IBOutlet weak var statusBox: UILabel!
    
    @IBOutlet weak var happyButton: UIButton!
    
    @IBOutlet weak var sarcasticButton: UIButton!
    
    @IBOutlet weak var loveButton: UIButton!
    
    @IBOutlet weak var angryButton: UIButton!
    
    @IBOutlet weak var partyButton: UIButton!
    
    @IBOutlet weak var sleepyButton: UIButton!
    
    @IBOutlet weak var upsetButton: UIButton!
    
    @IBOutlet weak var scaredButton: UIButton!
    
    @IBOutlet weak var cryButton: UIButton!
    
    @IBOutlet weak var resetButton: UIButton!
    
    @IBOutlet weak var informationButton: UIButton!
    
    
    // IBActions - Actions associated with IBOutlets
    
    @IBAction func happyButtonPressed(_ sender: Any) {
        happyButton.isHidden = true
        sarcasticButton.isHidden = true
        loveButton.isHidden = true
        angryButton.isHidden = true
        partyButton.isHidden = true
        sleepyButton.isHidden = true
        upsetButton.isHidden = true
        scaredButton.isHidden = true
        cryButton.isHidden = true
        
        // Update count, print new value
        happyCount += 1
        print("Happy count = \(happyCount)")
        statusBox.text = "Thanks for letting us know!"
        
        informationButton.isHidden = true
        resetButton.isHidden = false
    }
    
    @IBAction func sarcasticButtonPressed(_ sender: Any) {
        happyButton.isHidden = true
        sarcasticButton.isHidden = true
        loveButton.isHidden = true
        angryButton.isHidden = true
        partyButton.isHidden = true
        sleepyButton.isHidden = true
        upsetButton.isHidden = true
        scaredButton.isHidden = true
        cryButton.isHidden = true
        
        // Update count, print new value
        sarcasticCount += 1
        print("Sarcastic count = \(sarcasticCount)")
        statusBox.text = "Thanks for letting us know!"
        
        informationButton.isHidden = true
        resetButton.isHidden = false
    }
    
    @IBAction func loveButtonPressed(_ sender: Any) {
        happyButton.isHidden = true
        sarcasticButton.isHidden = true
        loveButton.isHidden = true
        angryButton.isHidden = true
        partyButton.isHidden = true
        sleepyButton.isHidden = true
        upsetButton.isHidden = true
        scaredButton.isHidden = true
        cryButton.isHidden = true
        
        // Update count, print new value
        loveCount += 1
        print("Love count = \(loveCount)")
        statusBox.text = "Thanks for letting us know!"
        
        informationButton.isHidden = true
        resetButton.isHidden = false
    }
    
    @IBAction func angryButtonPressed(_ sender: Any) {
        happyButton.isHidden = true
        sarcasticButton.isHidden = true
        loveButton.isHidden = true
        angryButton.isHidden = true
        partyButton.isHidden = true
        sleepyButton.isHidden = true
        upsetButton.isHidden = true
        scaredButton.isHidden = true
        cryButton.isHidden = true
        
        // Update count, print new value
        angryCount += 1
        print("Angry count = \(angryCount)")
        statusBox.text = "Thanks for letting us know!"
        
        informationButton.isHidden = true
        resetButton.isHidden = false
    }
    
    @IBAction func partyButtonPressed(_ sender: Any) {
        happyButton.isHidden = true
        sarcasticButton.isHidden = true
        loveButton.isHidden = true
        angryButton.isHidden = true
        partyButton.isHidden = true
        sleepyButton.isHidden = true
        upsetButton.isHidden = true
        scaredButton.isHidden = true
        cryButton.isHidden = true
        
        // Update count, print new value
        partyCount += 1
        print("Party count = \(partyCount)")
        statusBox.text = "Thanks for letting us know!"
        
        informationButton.isHidden = true
        resetButton.isHidden = false
    }
    
    @IBAction func sleepyButtonPressed(_ sender: Any) {
        happyButton.isHidden = true
        sarcasticButton.isHidden = true
        loveButton.isHidden = true
        angryButton.isHidden = true
        partyButton.isHidden = true
        sleepyButton.isHidden = true
        upsetButton.isHidden = true
        scaredButton.isHidden = true
        cryButton.isHidden = true
        
        // Update count, print new value
        sleepyCount += 1
        print("Sleepy count = \(sleepyCount)")
        statusBox.text = "Thanks for letting us know!"
        
        informationButton.isHidden = true
        resetButton.isHidden = false
    }
    
    @IBAction func upsetButtonPressed(_ sender: Any) {
        happyButton.isHidden = true
        sarcasticButton.isHidden = true
        loveButton.isHidden = true
        angryButton.isHidden = true
        partyButton.isHidden = true
        sleepyButton.isHidden = true
        upsetButton.isHidden = true
        scaredButton.isHidden = true
        cryButton.isHidden = true
        
        // Update count, print new value
        upsetCount += 1
        print("Upset count = \(upsetCount)")
        statusBox.text = "Thanks for letting us know!"
        
        informationButton.isHidden = true
        resetButton.isHidden = false
    }
    
    @IBAction func scaredButtonPressed(_ sender: Any) {
        happyButton.isHidden = true
        sarcasticButton.isHidden = true
        loveButton.isHidden = true
        angryButton.isHidden = true
        partyButton.isHidden = true
        sleepyButton.isHidden = true
        upsetButton.isHidden = true
        scaredButton.isHidden = true
        cryButton.isHidden = true
        
        // Update count, print new value
        scaredCount += 1
        print("Scared count = \(scaredCount)")
        statusBox.text = "Thanks for letting us know!"
        
        informationButton.isHidden = true
        resetButton.isHidden = false
    }
    
    @IBAction func cryButtonPressed(_ sender: Any) {
        happyButton.isHidden = true
        sarcasticButton.isHidden = true
        loveButton.isHidden = true
        angryButton.isHidden = true
        partyButton.isHidden = true
        sleepyButton.isHidden = true
        upsetButton.isHidden = true
        scaredButton.isHidden = true
        cryButton.isHidden = true
        
        // Update count, print new value
        cryCount += 1
        print("Cry count = \(cryCount)")
        statusBox.text = "Thanks for letting us know!"
        
        informationButton.isHidden = true
        resetButton.isHidden = false
    }
    
    @IBAction func resetButtonPressed(_ sender: Any) {
        happyButton.isHidden = false
        sarcasticButton.isHidden = false
        loveButton.isHidden = false
        angryButton.isHidden = false
        partyButton.isHidden = false
        sleepyButton.isHidden = false
        upsetButton.isHidden = false
        scaredButton.isHidden = false
        cryButton.isHidden = false

        statusBox.text = "How are you feeling today?"
        resetButton.isHidden = true
        informationButton.isHidden = false
    }

}

